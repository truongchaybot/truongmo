from core.chatbot import chat_with_bot
import json
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
HISTORY_PATH = os.path.join(BASE_DIR, "data", "history.json")

# Tải lịch sử
if os.path.exists(HISTORY_PATH):
    with open(HISTORY_PATH, "r", encoding="utf-8") as f:
        history = json.load(f)
else:
    history = []

# Nhập từ người dùng
while True:
    user_input = input("👤 Thầy: ")
    if user_input.lower() in ["exit", "quit"]:
        break
    history.append({"role": "user", "content": user_input})
    reply = chat_with_bot(user_input, history)
    print("🤖 Tiểu Vân:", reply)
    history.append({"role": "assistant", "content": reply})

    # Lưu lại lịch sử
    with open(HISTORY_PATH, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)
