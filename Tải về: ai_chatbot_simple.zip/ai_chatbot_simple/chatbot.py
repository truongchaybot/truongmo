import openai
import json
import os

# --- Load cấu hình từ file ---
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

openai.api_key = config["api_key"]
bot_name = config["bot_name"]
model = config["model"]
system_prompt = config["system_prompt"]

# Tạo đường dẫn file
history_path = "history.json"
spells_path = "spells.json"

# Tải lịch sử trò chuyện
if os.path.exists(history_path):
    with open(history_path, "r", encoding="utf-8") as f:
        history = json.load(f)
else:
    history = []

# Tải chú ngữ
if os.path.exists(spells_path):
    with open(spells_path, "r", encoding="utf-8") as f:
        spells = json.load(f)
else:
    spells = {}

def chat_with_bot(message, history):
    response = openai.ChatCompletion.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            *history,
            {"role": "user", "content": message}
        ]
    )
    reply = response.choices[0].message["content"]

    # Nếu có từ khóa "chú ngữ:", lưu lại
    if "chú ngữ:" in message.lower():
        key = message.strip().lower()
        spells[key] = reply
        with open(spells_path, "w", encoding="utf-8") as f:
            json.dump(spells, f, ensure_ascii=False, indent=2)

    return reply

# Vòng lặp trò chuyện
print("✨ Chatbot Tiểu Vân đã sẵn sàng. Gõ 'exit' để thoát.")
while True:
    user_input = input("👤 Thầy: ")
    if user_input.lower() in ["exit", "quit"]:
        break
    history.append({"role": "user", "content": user_input})
    reply = chat_with_bot(user_input, history)
    print("🤖 Tiểu Vân:", reply)
    history.append({"role": "assistant", "content": reply})

    # Lưu lại lịch sử
    with open(history_path, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)
